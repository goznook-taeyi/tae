const questions = [
  {
    q: "지금 당신의 기분에 가장 가까운 것은?",
    options: [
      "집중하고 싶은 마음",
      "아무 생각 없이 쉬고 싶은 느낌",
      "설레는 기대감",
      "괜히 예민해진 하루",
      "내 감정이 어떤지 잘 모르겠어요"
    ]
  },
  {
    q: "지금 가장 끌리는 감정은?",
    options: [
      "평온함",
      "생기와 에너지",
      "따뜻한 위로",
      "또렷한 집중력",
      "가볍고 유쾌한 기분"
    ]
  }
];

let current = 0;
const answers = [];

function renderQuestion() {
  const app = document.getElementById("app");
  if (!app) return;

  if (current >= questions.length) {
    app.innerHTML = `
      <h2>오늘의 추천 루틴</h2>
      <p>감정: 차분함 + 활력</p>
      <p>추천 향: 감국 + 솔잎</p>
      <p>콘텐츠: 명료한 집중을 위한 3분 숨 고르기</p>
    `;
    return;
  }

  const q = questions[current];
  app.innerHTML = `<h2>${q.q}</h2>` + q.options.map((opt, i) => `
    <button onclick="select('${opt}')">${opt}</button>
  `).join('');
}

function select(opt) {
  answers.push(opt);
  current++;
  renderQuestion();
}

renderQuestion();
